# ============================================================================
# AzureDiscovery.ps1 - Descoberta de Storage Accounts e Containers
# ============================================================================

function Get-TargetStorageAccounts {
    Write-Log "Buscando Storage Accounts..." "SECTION"
    $params = @{}
    if ($script:ResourceGroupName) {
        $params['ResourceGroupName'] = $script:ResourceGroupName
        Write-Log "Filtro Resource Group: $($script:ResourceGroupName)" "INFO"
    }
    try {
        $accounts = Get-AzStorageAccount @params
        if ($script:StorageAccountName) {
            $accounts = $accounts | Where-Object { $_.StorageAccountName -eq $script:StorageAccountName }
            Write-Log "Filtro Storage Account: $($script:StorageAccountName)" "INFO"
        }
        $accounts = $accounts | Where-Object { $_.Kind -in @('StorageV2','BlobStorage','BlockBlobStorage') }
        Write-Log "Encontradas $($accounts.Count) Storage Account(s) compatíveis" "INFO"
        return $accounts
    }
    catch {
        Add-ErrorDetail "Get-TargetStorageAccounts" $_.Exception.Message
        return @()
    }
}

function Get-ContainerImmutabilityInfo {
    param(
        [string]$AccountName,
        [string]$AccountResourceGroup,
        [Microsoft.Azure.Commands.Common.Authentication.Abstractions.IStorageContext]$StorageContext
    )
    $containersToProcess = @()
    try {
        $armContainers = Get-AzRmStorageContainer -ResourceGroupName $AccountResourceGroup -StorageAccountName $AccountName
        if ($script:ContainerName) {
            $armContainers = $armContainers | Where-Object { $_.Name -eq $script:ContainerName }
        }
        foreach ($armContainer in $armContainers) {
            $script:Stats.ContainersScanned++
            $containerInfo = [PSCustomObject]@{
                Name                    = $armContainer.Name
                HasImmutabilityPolicy   = $armContainer.HasImmutabilityPolicy
                HasLegalHold            = $armContainer.HasLegalHold
                ImmutabilityPolicyState = $null
                RetentionDays           = $null
                VersionLevelWorm        = $false
                LegalHoldTags           = @()
            }

            if ($armContainer.ImmutableStorageWithVersioning) {
                $containerInfo.VersionLevelWorm = $true
                Write-Log "  Container '$($armContainer.Name)': Version-level WORM habilitado" "INFO"
            }

            if ($armContainer.HasImmutabilityPolicy) {
                $script:Stats.ContainersWithPolicy++
                try {
                    $policy = Get-AzRmStorageContainerImmutabilityPolicy `
                        -ResourceGroupName $AccountResourceGroup `
                        -StorageAccountName $AccountName `
                        -ContainerName $armContainer.Name
                    $containerInfo.ImmutabilityPolicyState = $policy.State
                    $containerInfo.RetentionDays = $policy.ImmutabilityPeriodSinceCreationInDays
                    Write-Log "  Container '$($armContainer.Name)': Política=$($policy.State), Retenção=$($policy.ImmutabilityPeriodSinceCreationInDays)d" "INFO"
                }
                catch {
                    Write-Log "  Container '$($armContainer.Name)': Erro ao obter política - $($_.Exception.Message)" "WARN"
                }
            }

            if ($armContainer.HasLegalHold) {
                $containerInfo.LegalHoldTags = $armContainer.LegalHold.Tags | ForEach-Object { $_.Tag }
                Write-Log "  Container '$($armContainer.Name)': Legal Hold ativo (Tags: $($containerInfo.LegalHoldTags -join ', '))" "WARN"
            }

            $script:ContainerResults.Add($containerInfo)
            $containersToProcess += $armContainer.Name
        }
    }
    catch {
        Add-ErrorDetail "Get-ContainerImmutabilityInfo($AccountName)" $_.Exception.Message
    }
    return $containersToProcess
}
