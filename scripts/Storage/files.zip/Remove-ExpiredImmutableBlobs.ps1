<#
.SYNOPSIS
    Avalia e remove blobs com políticas de imutabilidade vencidas em Azure Blob Storage.

.DESCRIPTION
    Varre Storage Accounts e identifica blobs com imutabilidade expirada.
    Suporta container-level e version-level WORM, Legal Holds, paginação
    em lotes de 5000, e gera relatórios HTML/CSV.

.NOTES
    Versão: 2.0.0
    Requer: Az.Storage, Az.Accounts (PowerShell 7.0+)
    Estrutura: Script principal + lib/ (Helpers, AzureDiscovery, BlobPagination, BlobAnalysis, Reports)
#>

#Requires -Version 7.0
#Requires -Modules Az.Accounts, Az.Storage

[CmdletBinding(DefaultParameterSetName = 'DryRun')]
param(
    [Parameter()] [string]$SubscriptionId,
    [Parameter()] [string]$ResourceGroupName,
    [Parameter()] [string]$StorageAccountName,
    [Parameter()] [string]$ContainerName,
    [Parameter(ParameterSetName = 'DryRun')]        [switch]$DryRun,
    [Parameter(ParameterSetName = 'RemoveBlobs')]    [switch]$RemoveBlobs,
    [Parameter(ParameterSetName = 'RemovePolicyOnly')][switch]$RemoveImmutabilityPolicyOnly,
    [Parameter()] [string]$OutputPath = "./Reports",
    [Parameter()] [switch]$ExportCsv,
    [Parameter()] [switch]$IncludeSoftDeleted,
    [Parameter()] [switch]$VerboseProgress,
    [Parameter()] [int]$MaxDaysExpired = 0,
    [Parameter()] [int]$MinAccountSizeTB = 0,
    [Parameter()] [ValidateRange(100, 5000)] [int]$PageSize = 5000
)

# ============================================================================
# CARREGAR MÓDULOS
# ============================================================================
$scriptDir = $PSScriptRoot
if (-not $scriptDir) { $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path }
$libDir = Join-Path $scriptDir "lib"

. (Join-Path $libDir "Helpers.ps1")
. (Join-Path $libDir "AzureDiscovery.ps1")
. (Join-Path $libDir "BlobPagination.ps1")
. (Join-Path $libDir "BlobAnalysis.ps1")
. (Join-Path $libDir "Reports.ps1")

# ============================================================================
# CONFIGURAÇÃO GLOBAL (script scope para acesso em funções)
# ============================================================================
$ErrorActionPreference = "Stop"
$script:ScriptVersion = "2.0.0"
$script:StartTime = Get-Date
$script:Now = [DateTimeOffset]::UtcNow

# Parâmetros -> script scope
$script:SubscriptionId = $SubscriptionId
$script:ResourceGroupName = $ResourceGroupName
$script:StorageAccountName = $StorageAccountName
$script:ContainerName = $ContainerName
$script:VerboseProgress = $VerboseProgress.IsPresent
$script:MaxDaysExpired = $MaxDaysExpired
$script:PageSize = $PageSize

# Modo de operação
$script:DryRun = $false
$script:RemoveBlobs = $false
$script:RemoveImmutabilityPolicyOnly = $false

if ($PSBoundParameters.ContainsKey('RemoveBlobs')) { $script:RemoveBlobs = $true }
elseif ($PSBoundParameters.ContainsKey('RemoveImmutabilityPolicyOnly')) { $script:RemoveImmutabilityPolicyOnly = $true }
else { $script:DryRun = $true }

# Contadores globais
$script:Stats = @{
    StorageAccountsScanned = 0; ContainersScanned = 0; BlobsScanned = 0
    ContainersWithPolicy = 0; BlobsWithExpiredPolicy = 0; BlobsWithActivePolicy = 0
    BlobsWithLegalHold = 0; BlobsRemoved = 0; PoliciesRemoved = 0
    Errors = 0; ErrorDetails = [System.Collections.Generic.List[string]]::new()
    BytesEligible = 0; BytesScanned = 0; BytesRemoved = 0; PagesProcessed = 0
}

$script:Results = [System.Collections.Generic.List[PSCustomObject]]::new()
$script:ContainerResults = [System.Collections.Generic.List[PSCustomObject]]::new()

# ============================================================================
# EXECUÇÃO PRINCIPAL
# ============================================================================
function Start-ImmutabilityAudit {

    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "  Azure Blob Storage - Immutability Expiration Audit v$($script:ScriptVersion)" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""

    $mode = if ($script:RemoveBlobs) { "REMOÇÃO DE BLOBS" }
            elseif ($script:RemoveImmutabilityPolicyOnly) { "REMOÇÃO DE POLÍTICAS" }
            else { "SIMULAÇÃO (DryRun)" }

    Write-Log "Modo: $mode | PageSize: $($script:PageSize)" "SECTION"
    if ($script:VerboseProgress) { Write-Log "Verbose ATIVADO" "INFO" }
    if ($script:MaxDaysExpired -gt 0) { Write-Log "Filtro: expirados há mais de $($script:MaxDaysExpired) dias" "INFO" }
    if ($MinAccountSizeTB -gt 0) { Write-Log "Filtro threshold: $MinAccountSizeTB TB+" "INFO" }

    # Confirmação para modos destrutivos
    if ($script:RemoveBlobs -or $script:RemoveImmutabilityPolicyOnly) {
        Write-Host ""
        Write-Host "  ╔════════════════════════════════════════════════════════╗" -ForegroundColor Red
        Write-Host "  ║  ATENÇÃO: Ações destrutivas! Modo: $($mode.PadRight(23))║" -ForegroundColor Red
        Write-Host "  ╚════════════════════════════════════════════════════════╝" -ForegroundColor Red
        Write-Host ""
        $confirmation = Read-Host "  Digite 'CONFIRMAR' para prosseguir"
        if ($confirmation -ne 'CONFIRMAR') { Write-Log "Cancelado." "WARN"; return }
        Write-Host ""
    }

    if (-not (Test-AzureConnection)) { Write-Log "Falha na conexão Azure. Abortando." "ERROR"; return }

    if (-not (Test-Path $OutputPath)) { New-Item -ItemType Directory -Path $OutputPath -Force | Out-Null }

    $storageAccounts = Get-TargetStorageAccounts
    if ($storageAccounts.Count -eq 0) { Write-Log "Nenhuma Storage Account encontrada." "WARN"; return }

    $totalAccounts = @($storageAccounts).Count
    $accountIndex = 0

    foreach ($account in $storageAccounts) {
        $script:Stats.StorageAccountsScanned++
        $accountIndex++
        $accountName = $account.StorageAccountName
        $accountRG = $account.ResourceGroupName
        $accountStartTime = Get-Date
        $accountBlobsScanned = 0
        $accountBytesScanned = 0
        $accountEligibleBytes = 0
        $accountEligibleQueue = [System.Collections.Generic.List[PSCustomObject]]::new()

        Write-Log "Storage Account [$accountIndex/$totalAccounts]: $accountName (RG: $accountRG)" "SECTION"
        Show-Progress -Activity "Storage Accounts" -Status "[$accountIndex/$totalAccounts] $accountName" `
            -PercentComplete (($accountIndex - 1) / $totalAccounts * 100)

        try {
            $storageContext = $account.Context
            if (-not $storageContext) {
                $keys = Get-AzStorageAccountKey -ResourceGroupName $accountRG -Name $accountName
                $storageContext = New-AzStorageContext -StorageAccountName $accountName -StorageAccountKey $keys[0].Value
            }

            $containersToProcess = Get-ContainerImmutabilityInfo `
                -AccountName $accountName -AccountResourceGroup $accountRG -StorageContext $storageContext

            $totalContainers = @($containersToProcess).Count
            $containerIndex = 0

            foreach ($ctrName in $containersToProcess) {
                $containerIndex++
                $ctrStartTime = Get-Date
                $ctrBlobCount = 0; $ctrExpiredCount = 0; $ctrBytes = 0
                $blobsToProcess = [System.Collections.Generic.List[PSCustomObject]]::new()

                Write-Log "  Container [$containerIndex/$totalContainers]: $ctrName" "INFO"

                try {
                    $allBlobs = Get-BlobsPaginated `
                        -ContainerNameParam $ctrName `
                        -StorageContext $storageContext `
                        -AccountName $accountName `
                        -BatchSize $script:PageSize `
                        -IncludeVersions $true `
                        -IncludeDeleted $IncludeSoftDeleted.IsPresent

                    foreach ($blob in $allBlobs) {
                        $ctrBlobCount++
                        $script:Stats.BlobsScanned++
                        $script:Stats.BytesScanned += $blob.Length
                        $accountBlobsScanned++
                        $accountBytesScanned += $blob.Length
                        $ctrBytes += $blob.Length

                        if ($script:VerboseProgress -and ($ctrBlobCount % 500 -eq 0)) {
                            $tp = Get-Throughput -Count $ctrBlobCount -Since $ctrStartTime
                            Show-Progress -Activity "Storage Accounts" `
                                -Status "[$accountIndex/$totalAccounts] $accountName" `
                                -CurrentOperation "Ctr [$containerIndex/$totalContainers] $ctrName | Blob $ctrBlobCount | $tp | Expired: $ctrExpiredCount"
                        }

                        $blobResult = Test-BlobImmutabilityExpired -Blob $blob -AccountName $accountName -ContainerNameLocal $ctrName

                        if ($script:VerboseProgress -and $blobResult.Status -ne "NoPolicy") {
                            $icon = if ($blobResult.Status -eq "Expired") { "EXPIRED" } else { $blobResult.Status }
                            $shortName = if ($blob.Name.Length -gt 80) { $blob.Name.Substring(0,77)+"..." } else { $blob.Name }
                            $expInfo = if ($blobResult.DaysExpired -gt 0) { " | ${($blobResult.DaysExpired)}d" } else { "" }
                            $lvl = if ($blobResult.Status -eq "Expired") { "WARN" } else { "INFO" }
                            Write-VerboseLog "    [$icon] $shortName ($(Format-FileSize $blob.Length))$expInfo" $lvl
                        }

                        if ($blobResult.Status -eq "Expired") { $ctrExpiredCount++ }

                        if ($blobResult.Eligible) {
                            $accountEligibleBytes += $blob.Length
                            if (($script:RemoveBlobs -or $script:RemoveImmutabilityPolicyOnly) -and $MinAccountSizeTB -gt 0) {
                                $blobResult.Action = "PendingThreshold"
                                $accountEligibleQueue.Add($blobResult)
                            }
                            elseif ($script:RemoveBlobs -or $script:RemoveImmutabilityPolicyOnly) {
                                $blobsToProcess.Add($blobResult)
                            }
                            else {
                                $vL = if ($blobResult.VersionId) { " [v:$($blobResult.VersionId.Substring(0,[math]::Min(16,$blobResult.VersionId.Length)))]" } else { "" }
                                $blobResult.Action = "DryRun"
                                Write-Log "    DRYRUN: '$($blobResult.BlobName)'$vL - $($blobResult.DaysExpired)d ($($blobResult.LengthFormatted)) [$($blobResult.ImmutabilityMode)]" "INFO"
                            }
                        }

                        if ($blobResult.Status -ne "NoPolicy") { $script:Results.Add($blobResult) }
                    }

                    # FASE 3: Executar ações
                    if ($blobsToProcess.Count -gt 0) {
                        Write-Log "  Executando ações em $($blobsToProcess.Count) blob(s) de '$ctrName'..." "WARN"
                        $ai = 0
                        foreach ($bp in $blobsToProcess) {
                            $ai++
                            if ($script:VerboseProgress -and ($ai % 10 -eq 0)) {
                                Show-Progress -Activity "Ações" -Status $ctrName -PercentComplete (($ai/$blobsToProcess.Count)*100) `
                                    -CurrentOperation "$ai/$($blobsToProcess.Count)"
                            }
                            Invoke-BlobAction -BlobInfo $bp -StorageContext $storageContext
                        }
                    }

                    $ctrDur = ((Get-Date) - $ctrStartTime).ToString('hh\:mm\:ss')
                    $ctrTp = Get-Throughput -Count $ctrBlobCount -Since $ctrStartTime
                    Write-Log "  Resumo '$ctrName': $ctrBlobCount blobs | $(Format-FileSize $ctrBytes) | $ctrExpiredCount expirado(s) | $ctrTp | $ctrDur" "INFO"
                }
                catch {
                    Add-ErrorDetail "Container($ctrName)" $_.Exception.Message
                }
            }

            # Processar fila de threshold
            if (($script:RemoveBlobs -or $script:RemoveImmutabilityPolicyOnly) -and $MinAccountSizeTB -gt 0) {
                $thresholdBytes = [long]$MinAccountSizeTB * 1TB
                if ($accountBytesScanned -ge $thresholdBytes) {
                    Write-Log "Conta '$accountName' qualificada: $(Format-FileSize $accountBytesScanned) (limiar: ${MinAccountSizeTB}TB). Processando $($accountEligibleQueue.Count) blob(s)..." "WARN"
                    foreach ($qb in $accountEligibleQueue) { Invoke-BlobAction -BlobInfo $qb -StorageContext $storageContext }
                }
                else {
                    Write-Log "Conta '$accountName' abaixo do limiar: $(Format-FileSize $accountBytesScanned). Sem ação." "INFO"
                    foreach ($qb in $accountEligibleQueue) { $qb.Action = "SkippedBelowThreshold" }
                }
            }

            $accDur = ((Get-Date) - $accountStartTime).ToString('hh\:mm\:ss')
            Write-Log "Resumo '$accountName': $accountBlobsScanned blobs | $(Format-FileSize $accountBytesScanned) | Elegível: $(Format-FileSize $accountEligibleBytes) | $accDur" "SUCCESS"
        }
        catch {
            Add-ErrorDetail "Account($accountName)" $_.Exception.Message
        }
    }

    if ($script:VerboseProgress) { Write-Progress -Activity "Storage Accounts" -Completed }

    # --- RELATÓRIOS ---
    Write-Log "Gerando relatórios..." "SECTION"
    $ts = Get-Date -Format "yyyyMMdd_HHmmss"
    $htmlPath = Join-Path $OutputPath "ImmutabilityAudit_$ts.html"
    Export-HtmlReport -Path $htmlPath
    if ($ExportCsv) { Export-CsvReport -Path (Join-Path $OutputPath "ImmutabilityAudit_$ts.csv") }

    # --- RESUMO FINAL ---
    Write-Host ""
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host "  RESUMO DA EXECUÇÃO" -ForegroundColor Cyan
    Write-Host "============================================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Log "Storage Accounts:    $($script:Stats.StorageAccountsScanned)" "INFO"
    Write-Log "Containers:          $($script:Stats.ContainersScanned) (com política: $($script:Stats.ContainersWithPolicy))" "INFO"
    Write-Log "Páginas processadas: $($script:Stats.PagesProcessed)" "INFO"
    Write-Log "Blobs analisados:    $($script:Stats.BlobsScanned.ToString('N0')) ($(Format-FileSize $script:Stats.BytesScanned))" "INFO"
    Write-Host ""
    Write-Log "Imutab. vencida:     $($script:Stats.BlobsWithExpiredPolicy.ToString('N0'))" $(if($script:Stats.BlobsWithExpiredPolicy -gt 0){"WARN"}else{"SUCCESS"})
    Write-Log "Imutab. ativa:       $($script:Stats.BlobsWithActivePolicy.ToString('N0'))" "SUCCESS"
    Write-Log "Legal Hold:          $($script:Stats.BlobsWithLegalHold)" $(if($script:Stats.BlobsWithLegalHold -gt 0){"WARN"}else{"INFO"})
    Write-Log "Elegível remoção:    $(Format-FileSize $script:Stats.BytesEligible)" "INFO"

    if ($script:RemoveBlobs) {
        Write-Host ""
        Write-Log "Blobs removidos:     $($script:Stats.BlobsRemoved.ToString('N0'))" "SUCCESS"
        Write-Log "Espaço liberado:     $(Format-FileSize $script:Stats.BytesRemoved)" "SUCCESS"
    }
    if ($script:RemoveBlobs -or $script:RemoveImmutabilityPolicyOnly) {
        Write-Log "Políticas removidas: $($script:Stats.PoliciesRemoved.ToString('N0'))" "SUCCESS"
    }

    Write-Host ""
    Write-Log "Erros: $($script:Stats.Errors)" $(if($script:Stats.Errors -gt 0){"ERROR"}else{"SUCCESS"})
    if ($script:Stats.ErrorDetails.Count -gt 0 -and $script:Stats.ErrorDetails.Count -le 10) {
        foreach ($e in $script:Stats.ErrorDetails) { Write-Log "  - $e" "ERROR" }
    }
    elseif ($script:Stats.ErrorDetails.Count -gt 10) {
        foreach ($e in ($script:Stats.ErrorDetails | Select-Object -First 5)) { Write-Log "  - $e" "ERROR" }
        Write-Log "  ... +$($script:Stats.ErrorDetails.Count - 5) erros (veja relatório HTML)" "ERROR"
    }

    Write-Log "Duração: $((Get-Date) - $script:StartTime)" "INFO"
    Write-Host ""

    return [PSCustomObject]@{
        Stats = $script:Stats; Results = $script:Results
        ContainerResults = $script:ContainerResults; ReportPath = $htmlPath
    }
}

# Executar
Start-ImmutabilityAudit
